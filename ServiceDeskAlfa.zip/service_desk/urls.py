"""
URL configuration for service_desk project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from tickets import views

#urlpatterns = [
#    path("admin/", admin.site.urls),
#    path("tasks/", views.all_tasks, name = "tasks"),
#    path("tasks/<int:task_id>/", views.get_task, name = 'task'),
#    path("tasks/<int:task_id>/edit", views.edit_task, name = 'edit_task'),
#    path("login/auth", views.login, name = 'login')
    # path("/reports/summary/", views.todo),
    # path("/api/categories", views.todo),
    # path("/api/offices", views.todo),
#]


urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('tickets.urls')),  # основное приложение
]