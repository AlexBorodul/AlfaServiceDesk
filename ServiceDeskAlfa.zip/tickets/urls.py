from django.urls import path
from . import views

urlpatterns = [
    # Главная страница и заявки
    path('', views.all_tasks, name='tasks'),  # главная страница
    path('tasks/', views.all_tasks, name='tasks'),  # дублирующий маршрут для уверенности
    path('tasks/', views.all_tasks, name='tasks'),
    path('tasks/w', views.all_tasks_workers, name='tasks_w'),
    path('tasks/create/', views.create_task, name='create_task'),
    path('tasks/<int:task_id>/', views.get_task, name='task_detail'),
    path('tasks/<int:task_id>/edit/', views.edit_task, name='edit_task'),
    path('tasks/<int:task_id>/delete', views.delete_task, name='delete_task'),

    # Аутентификация
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),

    # Email и фидбек
    path('send-email/', views.send_message, name='send_email'),
    path('tasks/<int:task_id>/feedback/', views.feedback, name='feedback'),
    path('employees', views.all_users, name='users'),
    path('employees/<int:user_id>', views.user_by_id, name='user')
]

