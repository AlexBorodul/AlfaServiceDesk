from django import forms
from django.core.validators import EmailValidator
from django.forms import ModelForm
from tickets.models import Task

EMAIL_ADDRESS_MAX_LENGTH = 256

class TaskForm(forms.ModelForm):
    files = forms.FileField(required = False)
    class Meta:
        model = Task
        exclude = ("actual_cost", "author")
        widgets = {
            "title": forms.TextInput(attrs={"class": "form-control"}),
            "description": forms.Textarea(attrs={"class": "form-control", "rows": 5}),
            "priority": forms.Select(attrs={"class": "form-control"}),
            "status": forms.Select(attrs={"class": "form-control"}),
            "category": forms.Select(attrs={"class": "form-control"}),
            "office": forms.Select(attrs={"class": "form-control"}),
            "executor": forms.Select(attrs={"class": "form-control"}),
        }


class SendEmailForm(forms.Form):
    repicient = forms.EmailField(
        max_length = EMAIL_ADDRESS_MAX_LENGTH,
        validators=[EmailValidator]
    )
    mail_theme = forms.CharField(
        max_length = 100
    )
    text = forms.CharField()
    files = forms.FileField(required = False)

class FeedbackForm(forms.Form):
    FEEDBACK_RATING = [(str(i), i) for i in range(1, 6)]
    rating = forms.ChoiceField(choices=FEEDBACK_RATING)
    feedback = forms.CharField()

